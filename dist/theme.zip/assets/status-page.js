/*
	This is a skeleton Javascript file for the theme. Put your
	own JS in here or replace the file with your own scripts.
*/
window.onload = function() {
	// Handler for when the window loads.
};